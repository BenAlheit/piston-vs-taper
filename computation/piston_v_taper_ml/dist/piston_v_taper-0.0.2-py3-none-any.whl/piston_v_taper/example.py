print('Hi!')
